package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.User;
import com.app.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IUserService service;

	public UserController() {
		System.out.println("in cnstr " + getClass().getName());
	}

	// request handling method to show login form
	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "user/login";
	}

	// request handling method to process login form
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email, @RequestParam(name = "password") String pass,
			Model map,RedirectAttributes flashMap,HttpSession hs) {
		System.out.println("in process login form " + email + " " + pass+" "+map);
		// invoke service layer method for validation
		try {
			User u = service.validateUser(email, pass);
			// login successful -- chk role
			// vendor --redicrect clnt to details page
			//add status in flash map to be remembered till next request
			flashMap.addFlashAttribute("status", "Successful Login , "+u.getRole());
			if (u.getRole().equals("vendor")) {
				//store vendor dtls under session scope
				hs.setAttribute("vendor_dtls",u);
				//replace forward by redirect.
				return "redirect:/vendor/details";
				//D.S invokes response.sendRedirect(response.encodeRedirectURL("/vendor/details"))
			}
			// admin login
			return "redirect:/admin/list";
		} catch (RuntimeException e) {
			System.out.println("err in process login form " + e);
			// invalid login ---forward the clnt to login form highlighted with errs
			// add error mesg as a model attr
			map.addAttribute("status", "Invalid Login , Pls retry....");
			return "user/login";
		}
		
	}
	//request handling method for user's logout
	@GetMapping("/logout")
	public String logoutUser(HttpSession hs,Model map,HttpServletResponse response,HttpServletRequest rq)
	{
		System.out.println("in user logout");
		//save user details under req scope , retrieved from HS scope
		map.addAttribute("details", hs.getAttribute("vendor_dtls"));
		//discard session
		hs.invalidate();
		//set refresh header ---home page
		response.setHeader("refresh", "5;url="+rq.getContextPath());
		return "user/logout";
	}

}
