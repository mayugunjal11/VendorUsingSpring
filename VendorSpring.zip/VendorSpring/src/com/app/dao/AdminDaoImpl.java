package com.app.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.User;

@Repository
public class AdminDaoImpl implements IAdminDao 
{

	@Autowired
	private SessionFactory sf;
	
	public AdminDaoImpl() 
	{
		System.out.println("in ctor of"+getClass().getName());
	}
	
	@Override
	public List<User> getVendorList()
	{
		String jpql="select u from User u where u.role='vendor'";
		return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
	}

	@Override
	public List<User> getVendorList(int id) 
	{
		String jpql="select u from User u where u.role='vendor'";
		List<User>users=sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
		
		List<User>updatedlist=new ArrayList<User>();
		
		Session hs=sf.getCurrentSession();
		User u=hs.get(User.class,id);
		
		
		for (User user : users)
		{
			if(id==u.getId())
				hs.delete(u);
			else
				updatedlist.add(user);
		}
		
		return updatedlist;
	}

	@Override
	public String registerVendor(User u) 
	{
		sf.getCurrentSession().persist(u);
		return "Vendor registration successful with ID"+u.getId();
	}

}
