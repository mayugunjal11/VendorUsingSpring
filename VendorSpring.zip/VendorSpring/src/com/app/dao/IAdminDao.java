package com.app.dao;

import java.util.List;

import com.app.pojos.User;

public interface IAdminDao 
{
	List<User> getVendorList();
	List<User> getVendorList(int id);
	String registerVendor(User u);
}
