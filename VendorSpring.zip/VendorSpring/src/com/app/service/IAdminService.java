package com.app.service;

import java.util.List;

import com.app.pojos.User;

public interface IAdminService
{
	List<User> getVendorList();
	List<User> getVendorList(int id);
	String registerVendor(User u);
}
