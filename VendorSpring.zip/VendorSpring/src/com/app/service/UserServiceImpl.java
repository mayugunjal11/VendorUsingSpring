package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IUserDao;
import com.app.pojos.User;

@Service// To tell SC --contains B.L methods
@Transactional//to tell SC manage txs automatically
public class UserServiceImpl implements IUserService{
	@Autowired //byType
	private IUserDao dao;//field level D.I
	
	public UserServiceImpl() {
		System.out.println("in constr of "+getClass().getName());
	}

	@Override
	public User validateUser(String email, String pass) {
		// TODO Auto-generated method stub
		return dao.validateUser(email, pass);
	}

}
